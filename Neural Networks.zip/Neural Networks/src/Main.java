//Arjun Jain
//Honors Computer Science III
//Project: Neural Nets
//Purpose of class: Test Neural Net

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.*;

public class Main {

	public static void main(String[] args) {	
		//test_boolean_and();
		//test_boolean_xor();
		//test_digits();
		test_MNIST();
	}

	//Testing Neural Net on boolean AND operation
	//Parameters: 2 input sensors, 2 hidden neurons, 2 output neurons, and learning rate of 1.0
	public static void test_boolean_and() {
		//Create Neural Net
		NeuralNet boolean_and = new NeuralNet(2,2,2, 1.0);

		//Make ArrayList of training examples
		ArrayList<Example> training_examples = new ArrayList<Example>();

		//Each training example is an Example
		//Each Example takes a ArrayList of inputs and category_index - Have to use Arrays.asList to convert array to list  
		training_examples.add(new Example(new ArrayList(Arrays.asList(0.0,0.0)), 0));
		training_examples.add(new Example(new ArrayList(Arrays.asList(0.0,1.0)), 0));
		training_examples.add(new Example(new ArrayList(Arrays.asList(1.0,0.0)), 0));
		training_examples.add(new Example(new ArrayList(Arrays.asList(1.0,1.0)), 1));


		//Make ArrayList of testing examples
		ArrayList<Example> testing_examples = training_examples;

		//Set desired accuracy and run learn_many_examples with training and testing examples
		double desired_accuracy = 1.0;
		boolean_and.learn_many_examples(training_examples, testing_examples, desired_accuracy);
	}

	//Testing Neural Net on boolean XOR operation
	//Parameters: 2 input sensors, 2 hidden neurons, 2 output neurons, and learning rate of 0.05
	public static void test_boolean_xor() {
		//Create Neural Net 
		NeuralNet boolean_xor = new NeuralNet(2,2,2, 0.05);

		ArrayList<Example> training_examples = new ArrayList<Example>();
		training_examples.add(new Example(new ArrayList(Arrays.asList(0.0,0.0)), 0));
		training_examples.add(new Example(new ArrayList(Arrays.asList(0.0,1.0)), 1));
		training_examples.add(new Example(new ArrayList(Arrays.asList(1.0,0.0)), 1));
		training_examples.add(new Example(new ArrayList(Arrays.asList(1.0,1.0)), 0));

		ArrayList<Example> testing_examples = training_examples;

		double desired_accuracy = 1.0;
		boolean_xor.learn_many_examples(training_examples, testing_examples, desired_accuracy);
	}

	//Testing digits on Alpaydin and Kaynak's Handwritten Digits dataset
	//Given parameters: 64 inputs and 10 outputs
	public static void test_digits() {
		//Make SimpleFile for training and testing data
		SimpleFile training_data = new SimpleFile("digits-train.txt");
		SimpleFile testing_data = new SimpleFile("digits-test.txt");

		//Make ArrayList of training examples
		ArrayList<Example> training_examples = new ArrayList<Example>();

		//Make ArrayList of testing examples
		ArrayList<Example> testing_examples = new ArrayList<Example>();

		//for each line in the training data, make a training example
		for (String line : training_data) {
			//Separate line by commas into separate strings
			String[] split_line = line.split(",");
			//Get category from line 
			int category = Integer.parseInt(split_line[64]);
			//Get first 64 elements of string and add to list of training_inputs
			ArrayList<Double> training_inputs = new ArrayList<Double>();
			for(int i = 0; i < 64; i++) {
				double input_value = (double) Integer.parseInt(split_line[i]);
				training_inputs.add(input_value);
			}
			Example new_training_example = new Example(training_inputs, category);
			training_examples.add(new_training_example);
		}
		//for each line in the testing data:
		for (String line : testing_data) {
			//Separate line by commas into separate strings 
			String[] split_line = line.split(",");
			//Get category from line 
			int category = Integer.parseInt(split_line[64]);
			//Get first 64 elements of string and add to list of testing_inputs
			ArrayList<Double> testing_inputs = new ArrayList<Double>();
			for(int i = 0; i < 64; i++) {
				double input_value = (double) Integer.parseInt(split_line[i]);
				testing_inputs.add(input_value);
			}
			Example new_testing_example = new Example(testing_inputs, category);
			testing_examples.add(new_testing_example);
		}

/*OPTIMIZATION OF PARAMETERS for NeuralNet 	
		Slowly changed parameters to narrow down optimal parameters (number of hidden neurons, learning rate, and desired accuracy)
				int[] second_layer = {100, 150, 200}; 	   //number of hidden neurons
				double[] learning_rate = {0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09};
				double[] desired_accuracy = {0.99, 0.995};
				double test_max_accuracy = 0;
				int best_second_layer = 0;
				double best_learning_rate = 0;
				double best_desired_accuracy = 0;
				for(int i: second_layer) {
					for(double j : learning_rate) {
						NeuralNet handwritten_digits = new NeuralNet(64, i, 10, j);
						System.out.println("second layer: " + i + "," + "learning rate: " + j);
						for(double k: desired_accuracy) {
							System.out.println("desired accuracy: " + k);
							double accuracy = handwritten_digits.learn_many_examples(training_examples, testing_examples, k);
							if(accuracy > test_max_accuracy) {
								test_max_accuracy = accuracy;
								best_second_layer = i; 
								best_learning_rate = j;
								best_desired_accuracy = k;
							}
						}
					}
				}
				System.out.println(test_max_accuracy);
				System.out.println(best_second_layer);
				System.out.println(best_learning_rate);
				System.out.println(best_desired_accuracy);
*/
		//Found optimal parameters to be 100 hidden neurons, learning rate of 0.02, and desired accuracy of 0.995
		NeuralNet handwritten_digits = new NeuralNet(64,100,10, 0.02);
		double desired_accuracy = 0.995;
		handwritten_digits.learn_many_examples(training_examples, testing_examples, desired_accuracy);
	}
	
	//Testing NeuralNet on MNIST dataset
	//784 inputs and 10 outputs
	public static void test_MNIST() {
	    ArrayList<Example> trainingExamples = readData("train-labels.idx1-ubyte", "train-images.idx3-ubyte");
	    ArrayList<Example> testingExamples = readData("t10k-labels.idx1-ubyte", "t10k-images.idx3-ubyte");
		NeuralNet MNIST_digits = new NeuralNet(784, 20, 10, 0.1);
		double desired_accuracy = 0.965;
		MNIST_digits.learn_many_examples(trainingExamples, testingExamples, desired_accuracy);
	}
	
//Method to read files and create ArrayLists of training and testing examples
	static ArrayList<Example> readData(String labelFileName, String imageFileName) {
	    DataInputStream labelStream = openFile(labelFileName, 2049);
	    DataInputStream imageStream = openFile(imageFileName, 2051);

	    ArrayList<Example> examples = new ArrayList<>();

	    try {
	        int numLabels = labelStream.readInt();
	        int numImages = imageStream.readInt();
	        assert(numImages == numLabels) : "lengths of label file and image file do not match";
	        
	        int rows = imageStream.readInt();
	        int cols = imageStream.readInt();
	        assert(rows == cols) : "images in file are not square";
	        assert(rows == 28) : "images in file are wrong size";
	       
		int categoryLabel;
		ArrayList<Double> inputs;
		int pixel;	
	        for (int i = 0; i < numImages; i++) {
	            categoryLabel = Byte.toUnsignedInt(labelStream.readByte());
	            inputs = new ArrayList<Double>();
	            for (int r = 0; r < rows; r++) {
	                for (int c = 0; c < cols; c++) {
	                    pixel = 255 - Byte.toUnsignedInt(imageStream.readByte());
	                    inputs.add(r*rows + c, pixel / 255.0);
	                }
	            }
	            examples.add(new Example(inputs, categoryLabel));
	        }
	    } catch (IOException e) {
	        throw new RuntimeException(e);
	    }
	    return examples;
	}
//Method for opening files 
	static DataInputStream openFile(String fileName, int expectedMagicNumber) {
	    DataInputStream stream = null;
	    try {
	        stream = new DataInputStream(new BufferedInputStream(new FileInputStream(fileName)));
	        int magic = stream.readInt();
	        if (magic != expectedMagicNumber) {
	            throw new RuntimeException("file " + fileName + " contains invalid magic number");
	        }
	    } catch (FileNotFoundException e) {
	        throw new RuntimeException("file " + fileName + " was not found");
	    } catch (IOException e) {
	        throw new RuntimeException("file " + fileName + " had exception: " + e);
	    }
	    return stream;
	}
}




