//Arjun Jain
//Honors Computer Science III
//Project: Neural Nets
//Purpose of class: Define each example (either training or testing)

import java.util.ArrayList;

public class Example {

	//inputs to example 
	ArrayList<Double> inputs;	

	//category
	int category_index;

	//Constructor 
	Example(ArrayList<Double> inputs, int index) {
		this.inputs = inputs; 
		category_index = index;
	}

	//n is in the range 1...numOutputs.  
	//Returns 1 if you have the correct output, else returns 0
	public double getCorrectOutput(int n) {
		if(n == category_index) {
			return 1; 
		}
		else {
			return 0;
		}
	}


}
