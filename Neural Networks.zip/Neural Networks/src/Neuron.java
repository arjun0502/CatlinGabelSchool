//Arjun Jain
//Honors Computer Science III
//Project: Neural Nets
//Purpose of class: Define a Neuron (Hidden and Output Neuron)

import java.util.ArrayList;

public class Neuron {

	//Neurons = Hidden or Output neuron 
	//One hidden neuron is attached to every input sensor and a bias  
	//Each output neuron  is attached to every hidden neuron and a bias.

	//a list of weights for the "inputs" of a Neuron (inputs for hidden neuron = input sensors, inputs for output neurons = hidden neurons)
	ArrayList<Double> input_weights = new ArrayList<Double>();
	//the most recent output
	double most_recent_output;
	//The number of "inputs" corresponding to each Neuron
	//Does not include bias 
	int num_inputs;
	//weight for bias node
	double bias_weight;

	//constructor
	Neuron(int num_inputs) {
		this.num_inputs = num_inputs;
		//for each input, generate random value for weight between -0.05 and 0.05 and add to list of weights
		for(int i = 0; i < num_inputs; i++) {
			double rand_weight = -0.05 + Math.random() * 0.1;
			input_weights.add(rand_weight);
		}
		bias_weight = -0.05 + Math.random() * 0.1;
	}

	//Activation function
	public double activation_function(double sum) {
		return 1/(1 + Math.exp(-1*sum));
	}

	//update most recent output given inputs
	public void compute_recent_output(ArrayList<Double> inputs) {
		double sum = 0;
		sum += bias_weight;
		for(int j = 0; j < num_inputs; j++) {
			double input_value = inputs.get(j);
			sum += input_value * input_weights.get(j);
		}
		most_recent_output = activation_function(sum);
	}

	//Given the index for the ArrayList of input_weights, change the weight at that index by a certain amount
	public void update_input_weight(int index, double amount_change) {
		double previous_value = input_weights.get(index);
		input_weights.set(index, previous_value + amount_change);
	}

	//Change bias weight by certain amount
	public void update_bias_weight(double amount_change) {
		bias_weight += amount_change;
	}













}
