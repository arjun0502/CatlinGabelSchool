//Arjun Jain
//Honors Computer Science III
//Project: Neural Nets
//Purpose of class: Build a Neural Net and define how it learns

import java.util.ArrayList;
import java.util.Collections;

public class NeuralNet {

	//number of input sensors
	int numInputs;
	//number of hidden neurons
	int numHidden;
	//number of output neurons
	int numOutputs;
	//learning rate 
	double learning_rate;

	//ArrayLists of hidden neurons and output neurons
	ArrayList<Neuron> hidden_neurons = new ArrayList<Neuron>();
	ArrayList<Neuron> output_neurons = new ArrayList<Neuron>();

	//Constructor - when creating NeuralNet, you feed number of input sensors, number of hidden neurons, number of outputs, and learning rate
	NeuralNet(int numI, int numH, int numO, double learning_rt) {
		numInputs = numI;
		numHidden = numH;
		numOutputs = numO;
		learning_rate = learning_rt;

		//fill in ArrayList of hidden neurons  
		for(int i = 0; i < numHidden; i++) {
			Neuron new_hidden = new Neuron(numInputs);
			hidden_neurons.add(new_hidden);
		}
		//fill in ArrayList of output neurons
		for(int j = 0; j < numOutputs; j++) {
			Neuron new_output= new Neuron(numHidden);
			output_neurons.add(new_output);
		}
	}

	//takes one example and returns the category ("index") that the neural net thinks it belongs to
	public int classify_one_example(Example example) {

		//Set up ArrayList to store output of hidden neurons/inputs to output neurons
		ArrayList<Double> hidden_neuron_outputs = new ArrayList<Double>();

		//Initialize ArrayList to store output of output neurons
		ArrayList<Double> output_neuron_outputs = new ArrayList<Double>();

		//Fire each hidden neuron and add output to ArrayList
		for(int h = 0; h < numHidden; h++) {
			//Get a hidden neuron
			Neuron hidden_neuron = hidden_neurons.get(h);
			//Compute and store recent output of hidden neuron with list of inputs from example 
			hidden_neuron.compute_recent_output(example.inputs);
			hidden_neuron_outputs.add(hidden_neuron.most_recent_output);
		}

		//for each output neuron, compute the recent output and add to list
		for(int o = 0; o < numOutputs; o++) {
			Neuron output_neuron = output_neurons.get(o);
			output_neuron.compute_recent_output(hidden_neuron_outputs);
			output_neuron_outputs.add(output_neuron.most_recent_output);
		}
		//figure out the index of the greatest output 
		int index_highest_output = output_neuron_outputs.indexOf(Collections.max(output_neuron_outputs));			
		return index_highest_output;
	}


	//Takes one pre-categorized example, classifies it, and then learns by modifying the network's weights
	public void learn_one_example(Example example) {
		classify_one_example(example);

		//ArrayLists for error signals of output neurons and hidden neurons
		ArrayList<Double> output_error_signals = new ArrayList<Double>(numOutputs);
		ArrayList<Double> hidden_error_signals = new ArrayList<Double>(numHidden);

		//Calculate the output error signal for each output node o
		for(int o = 0; o < numOutputs; o++) {
			double actual_output = output_neurons.get(o).most_recent_output;
			double output_error_signal = (example.getCorrectOutput(o) - actual_output) * actual_output * (1-actual_output);
			output_error_signals.add(output_error_signal);
		}	

		//Calculate the hidden error signal for each hidden neuron h
		for(int h = 0; h < numHidden; h++) {
			double running_total = 0;
			//for each output neuron o: compute OutputErrorSignal x OutputWeight(a weight associated with link from hidden node h to output node o)
			for (int o = 0; o < numOutputs; o++) {
				//compute a running total of these products
				running_total += (output_error_signals.get(o)) * (output_neurons.get(o).input_weights.get(h));
			}
			//multiply running total by hidden_output
			double hidden_error_signal = running_total * (hidden_neurons.get(h).most_recent_output) * (1-hidden_neurons.get(h).most_recent_output);
			hidden_error_signals.add(hidden_error_signal);
		}

		//Update weight associated with link from hidden node h to output node o
		for(int o = 0; o < numOutputs; o++) {
			//update bias weight also
			output_neurons.get(o).update_bias_weight(output_error_signals.get(o) * learning_rate);
			for(int h = 0; h < numHidden; h++) {
				double change = output_error_signals.get(o) * hidden_neurons.get(h).most_recent_output * learning_rate;
				output_neurons.get(o).update_input_weight(h, change);
			}

		}
		//Update weight associated with link from input node i to hidden node h	
		for(int h = 0; h < numHidden; h++) {
			hidden_neurons.get(h).update_bias_weight(hidden_error_signals.get(h) * learning_rate);
			for(int i = 0; i < example.inputs.size(); i++) {
				double change = hidden_error_signals.get(h) * learning_rate * example.inputs.get(i);
				hidden_neurons.get(h).update_input_weight(i, change);
			}
		}
	}


	//Takes a list of pre-categorized training examples, and a desired training accuracy  
	//It repeatedly learns from the training examples until it reaches desired training accuracy
	public double learn_many_examples(ArrayList<Example> training_examples, ArrayList<Example> testing_examples, double desired_accuracy) {
		int epochs = 0;
		double current_accuracy = 0;
		while(current_accuracy < desired_accuracy) {
			for(int i = 0; i < training_examples.size(); i++) {
				learn_one_example(training_examples.get(i));
				if(i%100 == 0) {
					System.out.println("number of training examples = " + (i+1));
				}
			}
			current_accuracy = calculate_accuracy(training_examples);
			epochs += 1;
			System.out.println("current epoch number = " + epochs);
			System.out.println("current training accuracy = " + current_accuracy);
			System.out.println(" ");
		}
		//print total epochs, training accuracy, testing accuracy
		System.out.println("FINAL RESULTS: ");
		System.out.println("Total epochs is " + epochs);
		System.out.println("Testing accuracy is " + calculate_accuracy(training_examples));
		System.out.println("Testing accuracy is " + calculate_accuracy(testing_examples));
		return calculate_accuracy(testing_examples);
	}

	//Returns the fraction (or percent) of training/testing examples that are correctly classified by this network
	public double calculate_accuracy(ArrayList<Example> examples) {
		double num_correct_examples = 0;
		for(int i = 0; i < examples.size(); i++) {
			int predicted_output = classify_one_example(examples.get(i));
			if((examples.get(i).getCorrectOutput(predicted_output) == 1)) {
				num_correct_examples += 1;
			}
		}
		return (num_correct_examples)/(examples.size());
	}




}
