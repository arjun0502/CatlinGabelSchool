//Arjun Jain
//Honors Computer Science II - Block 4
//HashMap Test

public class TestforHashMaps {
	public static void main(String[] args) {

		SimpleMap<String,String> sounds = new MapFunctions<String,String>();

		System.out.println("get cow from empty map, should be null: " + sounds.get("cow"));

		sounds.put("cow", "moo");
		System.out.println("get cow, should be moo: " + sounds.get("cow"));

		sounds.put("pig", "oink");
		System.out.println("get pig, should be oink: " + sounds.get("pig"));
		System.out.println("get cow, should be moo: " + sounds.get("cow"));
		System.out.println("get fox, should be null: " + sounds.get("fox"));

		sounds.put("dog", "bark");
		System.out.println("get dog, should be bark: " + sounds.get("dog"));

		sounds.put("dog", "woof");
		System.out.println("get dog, should be woof: " + sounds.get("dog"));

		SimpleMap<String,Integer> legs = new MapFunctions<String,Integer>(2);

		legs.put("cow", 4);
		legs.put("snake", 0);
		legs.put("ant", 6);
		legs.put("bird", 2);
		legs.put("centipede", 100);

		System.out.println("get cow, should be 4: " + legs.get("cow"));
		System.out.println("get bird, should be 2: " + legs.get("bird"));
		System.out.println("get snake, should be 0: " + legs.get("snake"));
		System.out.println("get centipede, should be 100: " + legs.get("centipede"));
		System.out.println("get ant, should be 6: " + legs.get("ant"));
	}
}
