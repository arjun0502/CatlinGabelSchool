////Arjun Jain
//Honors Computer Science II - Block 4
//Custom List Node class for HashMap

public class ListNode<K,V> {

	//fields
	public K key;
	public V value;
	public ListNode<K,V> next;

	ListNode(K key, V value, ListNode<K,V> next)
	{
		this.key = key;
		this.value = value;
		this.next = next;
	}

	ListNode(K key, V value)
	{
		this.key = key;
		this.value = value;
		this.next = null;
	}

	public K getKey() {
		return key;
	}

	public V getValue() {
		return value;
	}

	public void setValue(V value) {
		this.value = value;
	}

	public ListNode<K,V> getNext() {
		return next;
	}

	public void setNext(ListNode<K,V> next) {
		this.next = next;        	
	}

}


