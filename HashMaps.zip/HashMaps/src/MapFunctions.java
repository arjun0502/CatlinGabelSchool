//Arjun Jain
//Honors Computer Science II - Block 4
//HashMap Functions

public class MapFunctions<K,V> implements SimpleMap<K,V> {
	private ListNode<K,V>[] hashtable; 
	private int Arraysize; 

	MapFunctions() {
		Arraysize = 10;
		Initializer();		
	}

	MapFunctions(int size) {
		Arraysize = size;
		Initializer();
	}

//Initializes the hashtable
	public void Initializer() {
		hashtable = new ListNode[Arraysize];
		for(int i = 0; i < Arraysize; i+= 1) {
			hashtable[i] = null; 	
		}
	}

//O(1)
	public V put(K key, V value) {
		//Get hash code
		int hash_code = (Math.abs(key.hashCode()))%Arraysize;
		//Create node to add to linked list
		ListNode<K,V> entry = new ListNode<K,V>(key,value);
		//Add the node if there is nothing there 
		if(hashtable[hash_code] == null) {
			hashtable[hash_code] = entry;
		//There is something there......
		}else{
			ListNode<K,V> current = hashtable[hash_code];
			while(current != null){
				//If the key already exists
				if(current.getKey().equals(key)){
					// Replace the keys value with the new one 
					current.setValue(value);
					return value;
				} 
				//key is not there, need to append to end of linked list 
				else if(current.next == null) {
					current.next = entry;
				}
				current = current.next;
			}
		}
		return null;	
	}

//O(1)
	public V get(K key) {
		int hash_code = (Math.abs(key.hashCode()))%Arraysize;	
		// Search for key in linked list 
		ListNode<K,V> n = hashtable[hash_code];
		// Traverse linked list
		while(n != null){
			if(n.getKey().equals(key)){
				return n.getValue();
			}
			n = n.getNext();
		}
		// Not found? then return null
		return null;
	}

}


