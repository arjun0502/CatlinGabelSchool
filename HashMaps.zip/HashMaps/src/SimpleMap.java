//Arjun Jain
//Honors Computer Science II - Block 4 
//HashMap Interface

public interface SimpleMap<K,V> {	
	public V put(K key, V value);
	public V get(K key);
}
