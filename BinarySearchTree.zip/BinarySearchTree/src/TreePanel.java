//Arjun Jain 
//Honors Computer Science II - Block 4
//May 26, 2018
//Program: TreePanel (helps provide a GUI interface to interact with trees)

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class TreePanel extends JPanel
{
  private BinarySearchTree tree;
  private TreeCanvas treeCanvas;
  private JTextField valueField;
  
  TreePanel(BinarySearchTree tree)
  {
    this.tree = tree;
    treeCanvas = new TreeCanvas();
    
    valueField = new JTextField(10);
    
    JButton insertButton = new JButton("Add");
    insertButton.addActionListener(new InsertListener());
    JButton removeButton = new JButton("Remove");
    removeButton.addActionListener(new RemoveListener());
    
    JPanel controlPanel = new JPanel();
    controlPanel.setLayout(new FlowLayout());
    controlPanel.add(new JLabel("Value: "));
    controlPanel.add(valueField);
    controlPanel.add(insertButton);
    controlPanel.add(removeButton);
    
    setLayout(new BorderLayout());
    add(treeCanvas, BorderLayout.CENTER);
    add(controlPanel, BorderLayout.SOUTH);
  }
  
  
  class InsertListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      String newValue = valueField.getText();
      tree.add(newValue);
      treeCanvas.draw();
    }
  }
  
  class RemoveListener implements ActionListener
  {
    public void actionPerformed(ActionEvent event)
    {
      String newValue = valueField.getText();
      tree.remove(newValue);
      treeCanvas.draw();
    }
  }
  
  class TreeCanvas extends ImageCanvas
  {
	  TreeCanvas() {
		  super(900,600);
	  }
 
	  void draw() {
		    Graphics pen = getPen();
		    int width =  getWidth();
		    int height = getHeight();
		    pen.setColor(Color.WHITE);
		    pen.fillRect(0, 0, width, height);
		    pen.setColor(Color.BLACK);
		    tree.drawTree(pen, width, height);
		    display();
		  }
	  
	  public void resized() {
		  draw();
	  }
  }
  
  
}