//Arjun Jain 
//Honors Computer Science II - Block 4
//May 26, 2018
//Program: TreeWindow (helps provide a GUI interface to interact with trees, used to test methods)

import javax.swing.*;

public class TreeWindow 
{
  TreeWindow(BinarySearchTree tree) 
  { 
    TreePanel treePanel = new TreePanel(tree);

    JFrame frame;
    frame = new JFrame("Binary Search Tree");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.getContentPane().add(treePanel);
    frame.pack();
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
    frame.toFront();
  }
  
  public static void main(String[] args)
  {
    BinarySearchTree t = new ArjunBinarySearchTree();
    
    System.out.println(t.isEmpty() + " should be true");
    t.add("M");
    System.out.println(t.isEmpty() + " should be false");
    System.out.println(t.contains("M") + " should be true");
    System.out.println(t.contains("F") + " should be false");
    t.add("Q");
    System.out.println(t.contains("Q") + " should be true");
    System.out.println(t.contains("H") + " should be false");
    t.add("B");
    t.add("C");
    System.out.println(t.contains("B") + " should be true");
    System.out.println(t.contains("D") + " should be false");
    t.add("F");
    t.add("D");
    t.add("A");
    t.add("I");
    t.add("G");
    t.add("J");
    t.add("U");
    t.add("W");
    t.add("X");
    t.add("Z");
    t.add("Y");
    t.add("T");
    t.add("V");
    t.add("S"); 
    
    System.out.println("///////////");
    System.out.println("In Order:");
    t.printInOrder();
    System.out.println("///////////");
    System.out.println("Pre Order:");
    t.printPreOrder();
    System.out.println("///////////");
    System.out.println("Post Order:");
    t.printPostOrder();
    TreeWindow treeWindow = new TreeWindow(t);
    
    
  }
}