//Arjun Jain 
//Honors Computer Science II - Block 4
//May 26, 2018
//Program: ArjunBinarySearchTree (implements BinarySearchTree interface)

import java.awt.Graphics;
import java.util.ArrayList;
import org.omg.CORBA.Current;

public class ArjunBinarySearchTree implements BinarySearchTree {

	private TreeNode root;

	public ArjunBinarySearchTree() {
		root = null;
	}

	public boolean contains(Comparable targetValue) {
		if (root == null) {
			return false;
		}
		TreeNode current = root;
		while (current != null) {
			Comparable cval = current.getValue();
			if (targetValue.compareTo(cval) == 0) {
				return true;
			} else if (targetValue.compareTo(cval) < 0) {
				current = current.getLeft();

			} else if (targetValue.compareTo(cval) > 0) {
				current = current.getRight();
			}
		}
		return false;
	}

	
	public void add(Comparable newValue) {
		TreeNode newNode = new TreeNode(newValue);
		if (root == null) {
			root = newNode;
			return;
		}
		TreeNode current = root;
		while (current != null) {
			if (newValue.compareTo(current.getValue()) < 0) {
				if (current.getLeft() == null) {
					current.setLeft(newNode);
					break;
				}
				current = current.getLeft();
			} else {
				if (current.getRight() == null) {
					current.setRight(newNode);
					break;
				}
				current = current.getRight();
			}

		}
	}

//Remove method from interface, uses private remove method with more arguments
	public void remove(Comparable targetValue) {
		root = remove(targetValue, root);
	}

	private TreeNode remove(Comparable targetValue, TreeNode root) {
		if (root == null) {
			return root;
		}
		//recursion 
		if (targetValue.compareTo(root.getValue()) < 0) {
			root.setLeft(remove(targetValue, root.getLeft()));
		} else if (targetValue.compareTo(root.getValue()) > 0) {
			root.setRight(remove(targetValue, root.getRight()));
		} else {
			// node with no children
			if (root.getLeft() == null && root.getRight() == null) {
				return null;
			}
			// node with one child (no left child)
			else if (root.getLeft() == null) {
				return root.getRight();
			}
			// node with one child(no right child)
			else if (root.getRight() == null) {
				return root.getLeft();
			} else {
				//node with two children
				//search for min number in right sub tree
				Comparable minValue = minimumValue(root.getRight());
				root.setValue(minValue);
				root.setRight(remove(minValue, root.getRight()));
			}
		}
		return root;
	}

//Helper method for remove - returns minimum Comparable value in tree
	private Comparable minimumValue(TreeNode root) {
		if (root.getLeft() != null) {
			return minimumValue(root.getLeft());
		} else {
			return root.getValue();
		}
	}


	public boolean isEmpty() {
		return root == null;
	}


	public void printInOrder() {
		printInOrder(root);
	}

//Private method for printInOrder with argument
	private void printInOrder(TreeNode node) {
		if (node == null) {
			return;
		}
		printInOrder(node.getLeft());
		System.out.println(node.getValue());
		printInOrder(node.getRight());
	}

	public void printPostOrder() {
		printPostOrder(root);
	}
	
//Private method for printPostOrder with argument
	private void printPostOrder(TreeNode node) {
		if (node == null) {
			return;
		}
		printInOrder(node.getLeft());
		printInOrder(node.getRight());
		System.out.println(node.getValue());

	}

	public void printPreOrder() {
		printPreOrder(root);
	}

//Private method for printPreOrder with argument
	private void printPreOrder(TreeNode node) {
		if (node == null) {
			return;
		}
		System.out.println(node.getValue());
		printInOrder(node.getLeft());
		printInOrder(node.getRight());
	}

//drawTree method from BinarySearchTree interface - uses helper methods 
	public void drawTree(Graphics pen, int screenWidth, int screenHeight) {
		int num_nodes = count_nodes(root);
		int horizontal_gap = screenWidth / (num_nodes + 1);
		int num_levels = get_Height(root);
		int vertical_gap = screenHeight / (num_levels + 1);
		prev_x = 0;
		assign_X(root, horizontal_gap);
		assign_Y(root, vertical_gap, 0);
		draw(pen, root);
	}

//Helper method for drawTree - assigns values to the x-coordinates of nodes	
	int prev_x;
	private void assign_X(TreeNode current, int horizontal_gap) {

		if (current == null) {
			return;
		}
		assign_X(current.getLeft(), horizontal_gap);
		current.x_coord = horizontal_gap + prev_x;
		prev_x = current.x_coord;
		assign_X(current.getRight(), horizontal_gap);
	}

//Helper method for drawTree - assigns values to the y-coordinates of nodes
	private void assign_Y(TreeNode current, int vertical_gap, int prev_y) {

		if (current == null) {
			return;
		}
		current.y_coord = vertical_gap + prev_y;
		assign_Y(current.getLeft(), vertical_gap, current.y_coord);
		assign_Y(current.getRight(), vertical_gap, current.y_coord);
	}

//Private method for drawing the tree with "current" node and pen as argument	
	private void draw(Graphics pen, TreeNode current) {
		if (current == null) {
			return;
		}
		draw(pen, current.getLeft());
		pen.drawOval(current.x_coord, current.y_coord, 40, 40);
		pen.drawString((String) current.getValue(), current.x_coord + 15, current.y_coord + 25);
		if (current.getLeft() != null) {
			pen.drawLine(current.x_coord + 5, current.y_coord + 35, current.getLeft().x_coord + 15,
					current.getLeft().y_coord);
		}
		if (current.getRight() != null) {
			pen.drawLine(current.x_coord + 15, current.y_coord + 40, current.getRight().x_coord,
					current.getRight().y_coord + 10);
		}
		draw(pen, current.getRight());

	}

//Helper method for drawTree to count number of nodes in tree
	private int count_nodes(TreeNode current) {
		if (current == null) {
			return 0;
		} else {
			return 1 + count_nodes(current.getLeft()) + count_nodes(current.getRight());

		}
	}

//Helper method for drawTree to find the height of the current tree 	
	private int get_Height(TreeNode current) {
		if (current == null) {
			return 0;
		} else {
			int lDepth = get_Height(current.getLeft());
			int rDepth = get_Height(current.getRight());

			if (lDepth > rDepth) {
				return (lDepth + 1);
			} else {
				return (rDepth + 1);
			}
		}
	}

}
