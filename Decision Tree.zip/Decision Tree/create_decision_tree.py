#Arjun Jain 
#Honors Computer Science III
#Decision Tree Induction Project
#Program to create decision tree 

import math
import random
from collections import defaultdict

# Calculates the entropy of the given data set
def entropy(data, classification_attr):
    freq_values = frequencies([l[classification_attr] for l in data])
    sum_frequencies = float(sum([x[1] for x in freq_values]))
    data_entropy = 0
    for val, frequency in freq_values:
        p_value = frequency / sum_frequencies
        data_entropy += (-p_value * math.log(p_value, 2))
    return data_entropy

# Calculates the information gain that would result by splitting the data on "split_attr"
def information_gain(data, split_attr, classification_attr):
    data_entropy = entropy(data, classification_attr)
    split_attr_freq_values = frequencies([instance[split_attr] for instance in data])
    total_subset_entropy = 0.0
    for value, value_freq in split_attr_freq_values:
        p_value = value_freq / float(len(data))
        data_subset = filter_instances(data, split_attr, value)
        total_subset_entropy += p_value * entropy(data_subset, classification_attr)
    return data_entropy - total_subset_entropy

# Returns a list of value-frequency pairs for a given list
def frequencies(values):
    freqs = defaultdict(int)
    for value in values:
        freqs[value] += 1.0
    return freqs.items()

# Returns the majority for values associated with "attribute" in the data
def majorit_values(data, attribute="target"):
    if not data:
        raise ValueError("Can't have a majority of no data")
    freqs = frequencies([x[attribute] for x in data])
    return max(freqs, key=lambda x: x[1])[0]

# Returns the set of values for an attribute
def attribute_values(data, attribute):
    return set([x[attribute] for x in data])

# Filters instances in the data that do not have a "value" for "attribute"
def filter_instances(data, attribute, value):
    return [x for x in data if x[attribute] == value]

# Iterates through all the attributes and returns the attribute with the highest gain
def _choose_attribute(data, attributes, classification_attr):
    if not all((data, attributes)):
        raise AttributeError("Can't choose %s from %s" % (attributes, data))
    gains = [(attr, information_gain(data, attr, classification_attr)) for attr in attributes]
    return max(gains, key=lambda x: x[1])[0]

# Builds a decision tree
def create_decision_tree(data, attributes, tar_attr_name="target"):
    if not data:
        raise ValueError("No data to make tree out of")
    classes = [record[tar_attr_name] for record in data]
    default_class = majorit_values(data, attribute=tar_attr_name)
    if not attributes:
        return default_class
    if len(set(classes)) == 1:
        return classes[0]
    nxt_attr = _choose_attribute(data, attributes, tar_attr_name)
    tree = {nxt_attr: {}}
    nxt_attr_vals = set([record[nxt_attr] for record in data])
    for value in nxt_attr_vals:
        matching_data = filter_instances(data, nxt_attr, value)
        attributes = [x for x in attributes if x != nxt_attr]
        subtree = create_decision_tree(matching_data, attributes, tar_attr_name=tar_attr_name,)
        tree[nxt_attr][value] = subtree
    return tree

class DecisionTree(object):

    # Initializes the Decision Tree Class
    def __init__(self, data, attributes, classification_attr_name="target"):
        self.data = data
        self.attributes = attributes
        self.classification_attr_name = classification_attr_name
        self.tree = create_decision_tree(data, attributes, tar_attr_name=classification_attr_name)

    # Returns the classification for "instance" using the tree
    def _classify_instance(self, instance, tree):
        if isinstance(tree, dict):
            split_attr = tree.keys()[0]
            instance_value = instance[split_attr]
            if instance_value not in tree[split_attr].iterkeys():
                targetVals = list(set([self.data[i][self.classification_attr_name] for i in range(len(self.data))]))
                index = random.randint(0, len(targetVals)-1)
                sub_tree = targetVals[index]
            else:
                sub_tree = tree[split_attr][instance_value]
            return self._classify_instance(instance, sub_tree)
        return (instance, tree)

    # Classifies the instances provided using the tree
    def classify(self, data):
        return [self._classify_instance(instance, self.tree) for instance in data]
    
    def print_tree(self, tree, counter):
        tabs = ''
        for val in range(counter):
            tabs+='\t'
        if isinstance(tree, dict):
            for item in tree.keys():
                print(tabs + item + ":")
                self.print_tree(tree[item], counter+1)
        else:
            print(tabs+tree)
    
    def depth(self, d, level):
        if not isinstance(d, dict) or not d:
            return level
        return max(self.depth(d[k], level + 1) for k in d)
    
    def total_nodes(self, d):
        return (1 if not isinstance(d, dict) else len(d) + sum(self.total_nodes(v) for v in d.values()))
