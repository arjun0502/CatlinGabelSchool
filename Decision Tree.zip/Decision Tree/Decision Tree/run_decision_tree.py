#Arjun Jain 
#Honors Computer Science III
#Decision Tree Induction Project
#Program to run decision tree 


from create_decision_tree import DecisionTree
import random

# Opens file and creates a list of dictionaries based on data set
f = open("tennis.txt", 'r')
lines = f.readlines()
header = lines[0].strip().split(",")
lines = lines[1:]
f.close()
temp = []
for line in lines:
    line = line.strip().split(",")
    temp.append(line)
temp = [{header[item]:line[item] for item in range(len(header))} for line in temp]

# Configerable proportions of data to be set for training (rest will be allocated to test)
total_length = len(temp)
training_percentage = 1.0

# Shuffles and partitions data set into two different lists (building the tree and testing the tree)
random.shuffle(temp)
starting_index = int(total_length*training_percentage)
data = temp[:starting_index]
test = temp[starting_index:]

if __name__ == '__main__':

    # Creates the Decision Tree and prints it
    tree = DecisionTree(data, header[1:], classification_attr_name=header[0])
    tree.print_tree(tree.tree, 0)
    print('\n')
    print("Total Number of Nodes in Tree: " + str(tree.total_nodes(tree.tree)))
    print("Total Depth of Tree: " + str(tree.depth(tree.tree, 1)))   
            
    # Calculates and counts the percent correct from the testing list
    correct = 0
    count = 0
    for item in test:
        count+= 1.0
        aa = item[header[0]]
        del item[header[0]]
        a = tree.classify([item])
        if aa == a[0][1]:
            correct += 1.0
    print("Total Tested: " + str(count))
    if count!=0:
        print("Number correct: " + str(correct))        
        print("Accuracy: " + str((correct/count)*100) + "%")
