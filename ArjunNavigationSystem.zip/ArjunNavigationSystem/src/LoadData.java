//Arjun Jain 
//Honors Computer Science II - Block 4
//June 14 2018
//Purpose: 1)To load the links, waypoints, and nodes from a file into data structures 2) closestNode method 3) Djikstra's algorithm

import java.util. *;
import java.io.*;
import java.lang.Math.*;
import java.util.PriorityQueue;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class LoadData {
	HashMap<Integer,Node> nodes = new HashMap<Integer,Node>();
	HashMap<Integer,Link> links = new HashMap<Integer,Link>();
	double maxLong = Double.NEGATIVE_INFINITY;
	double minLong = Double.POSITIVE_INFINITY;
	double maxLat = Double.NEGATIVE_INFINITY;
	double minLat = Double.POSITIVE_INFINITY;
	int links_size;


	public LoadData(String dataFolder) {

		//loading nodes files 
		try {
			String nodesFileName = dataFolder + "/nodes.bin";
			DataInputStream inStream = new DataInputStream(new BufferedInputStream(new FileInputStream(nodesFileName)));
			int numNodes = inStream.readInt();
			for (int i=0; i<numNodes; i++) {
				int nodeID = inStream.readInt();
				double longitude = inStream.readDouble();
				double latitude = inStream.readDouble();
				nodes.put(nodeID, new Node(longitude, latitude, nodeID));
				if(longitude > maxLong)
					maxLong = longitude;
				if(longitude < minLong)
					minLong = longitude;
				if(latitude > maxLat)
					maxLat = latitude;
				if(latitude < minLat)
					minLat = latitude;
			}
			inStream.close();
		}
		catch (IOException e) {
			System.err.println("error on nodes.bin: " + e.getMessage());
		}		   

		//loading links files
		try {
			String linksFilesName = dataFolder + "/links.bin";
			DataInputStream inStreamL = new DataInputStream(new BufferedInputStream(new FileInputStream(linksFilesName)));
			int numLinks = inStreamL.readInt();
			for (int i=0; i<numLinks; i++) {
				int linkID = inStreamL.readInt();
				int startNodeID = inStreamL.readInt();
				int endNodeID = inStreamL.readInt();
				String name = inStreamL.readUTF();
				double length = inStreamL.readDouble();
				byte numWays = inStreamL.readByte();
				Link new_link = new Link(linkID, nodes.get(startNodeID), nodes.get(endNodeID), name, length, numWays);
				links.put(linkID, new_link);
				nodes.get(startNodeID).neighbors.add(new_link);
				if(numWays == 2) {
					Link new_link2 = new Link(-(linkID), nodes.get(endNodeID), nodes.get(startNodeID), name, length, numWays);
					links.put(-(linkID), new_link2);
					nodes.get(endNodeID).neighbors.add(new_link2);
				}
			}
			links_size = numLinks;
			inStreamL.close();
		}
		catch (IOException e) {
			System.err.println("error on links.bin: " + e.getMessage());
		}	

		//load way-link files
		try {
			String links_waypointsFilesName = dataFolder + "/links-waypoints.bin";
			DataInputStream inStreamLW = new DataInputStream(new BufferedInputStream(new FileInputStream(links_waypointsFilesName)));
			for (int i=0; i<links_size; i++) {
				ArrayList<Link_waypoints> way_points_list;
				ArrayList<Link_waypoints> way_points_list2 = null;
				int linkID = inStreamLW.readInt();
				way_points_list = links.get(linkID).getArray();
				if(links.get(linkID).numWays == 2) {
					way_points_list2 = links.get(-(linkID)).getArray();
				}
				int numWaypoints = inStreamLW.readInt();
				for(int j = 0; j < numWaypoints; j ++) {
					double longitude = inStreamLW.readDouble();
					double latitude = inStreamLW.readDouble();
					Link_waypoints new_waypoint = new Link_waypoints(longitude, latitude);
					way_points_list.add(new_waypoint);
					if(links.get(linkID).numWays == 2) {
						way_points_list2.add(new_waypoint);
					}

				}
			}
			inStreamLW.close();
		}
		catch (IOException e) {
			System.err.println("error on links_waypoints.bin: " + e.getMessage());
		}	
	}


	//Method to find closest node to a longitude and latitude 
	public Node closestNode(double longitutude, double latitude) {
		int closestNode_ID = 0;
		Double min_dist = Double.POSITIVE_INFINITY;
		for(int nodeID: nodes.keySet()) {
			double dist_long = nodes.get(nodeID).longitude - longitutude;
			double dist_lat = nodes.get(nodeID).latitude - latitude;
			double dist = Math.sqrt(Math.pow(dist_long, 2) + Math.pow(dist_lat, 2));
			if(dist < min_dist) {
				min_dist = dist;
				closestNode_ID = nodeID;
			}
		}
		return nodes.get(closestNode_ID);
	}




	//Djikstra's algorithm to find shortest path between two nodes
	//returns an arraylist of nodes (with the endNode at the start)
	public ArrayList<Node> shortestPath(Node startNode, Node endNode) {
		//reset minDistance of nodes to big value and previous 
		for(int key: nodes.keySet()) {
			nodes.get(key).minDistance = Double.MAX_VALUE;
			nodes.get(key).previous = null;
		}

		startNode.minDistance = 0;
		//PriorityQueue of "Frontier" nodes 
		PriorityQueue<Node> frontierQueue = new PriorityQueue<Node>();
		frontierQueue.add(startNode);

		while (!frontierQueue.isEmpty()) {
			//select node from frontier with smallest path length to start 
			Node u = frontierQueue.poll();
			if (u == endNode)
			{
				System.out.println("path is found");
				break;
			}

			// Visit each neighbor
			for (Link e : u.neighbors)
			{
				//compute length of new path to neighbor from start via this node
				Node neighbor = e.endNode;
				double length = e.length;
				double distanceToU = u.minDistance + length;

				//if length is better than previously stored length, update the node and frontier
				if (distanceToU < neighbor.minDistance) 
				{
					frontierQueue.remove(neighbor);
					neighbor.minDistance = distanceToU ;
					neighbor.previous = u;
					frontierQueue.add(neighbor);
				}
			}
		}
		ArrayList<Node> path = new ArrayList<Node>();
		for (Node node = endNode; node != null; node = node.previous)
			path.add(node);
		return path;   
	}

}


