//Arjun Jain 
//Honors Computer Science II - Block 4
//June 14 2018
//Purpose: Class for node objects 
import java.util.ArrayList;

public class Node implements Comparable<Node>
{
  double latitude;
  double longitude;
  int nodeID;
  double minDistance = Double.POSITIVE_INFINITY;
  
  public ArrayList<Link> neighbors = new ArrayList<Link>();
  Node previous;
    
  public Node(double longitude, double latitude, int nodeID) {
	   this.longitude = longitude;
	   this.latitude = latitude;
	   this.nodeID = nodeID;
}

public int compareTo(Node other)
  {
    return Double.compare(minDistance, other.minDistance);
  }
  
}