//Arjun Jain 
//Honors Computer Science II - Block 4
//June 14 2018
//Purpose: Contains code for drawing the panel and buttons, dictates action when clicking the button, and creates a KML file

import java.awt.*;
import java.awt.event.*;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.*;
import javax.swing.border.*;

class ControlPanel extends JPanel
{
	ViewCanvas canvas;
	ControlPanel(ViewCanvas canvas) 
	{
		JPanel actionPanel = new JPanel();
		actionPanel.setLayout(new FlowLayout());
		actionPanel.setBorder(new TitledBorder("Path Finding"));
		JButton findPathButton = new JButton("Find Path");
		findPathButton.addActionListener(new FindPathButtonListener());
		actionPanel.add(findPathButton);
		this.canvas = canvas;
		setLayout(new BorderLayout());
		add(actionPanel, BorderLayout.EAST);
	}

	class FindPathButtonListener implements ActionListener
	{
		public void actionPerformed(ActionEvent event)
		{
			long startTime = System.currentTimeMillis();
			canvas.node_list = canvas.map.shortestPath(canvas.node1, canvas.node2);
			long stopTime = System.currentTimeMillis();
			double duration = (double) ((stopTime-startTime) / 1000.0);
			canvas.draw();
			Collections.reverse(canvas.node_list);
			int num_nodes = 0;
			for (Node n: canvas.node_list)
				num_nodes += 1;
			System.out.println("Total Distance: " + canvas.node2.minDistance);
			System.out.println("num_nodes: " + num_nodes);
			System.out.println("Time taken: " + duration + "seconds");

			//Making a KML file 
			SimpleFile file = new SimpleFile("ArjunsPath.kml");

			file.startWriting();
			PrintStream stream = file.getPrintStream();

			stream.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
			stream.println("<kml xmlns=\"http://www.opengis.net/kml/2.2\">");
			stream.println("<Document>");	
			stream.println("<name>Arjun's Path Finder</name>");
			stream.println("<Placemark>");
			stream.println("<name>Start</name>");
			stream.println("<Point><coordinates>" + canvas.node1.longitude + "," + canvas.node1.latitude + "</coordinates></Point>");
			stream.println("</Placemark>");
			stream.println("<Placemark>");
			stream.println("<name>End</name>");
			stream.println("<Point><coordinates>" + canvas.node2.longitude + "," + canvas.node2.latitude + "</coordinates></Point>");
			stream.println("</Placemark>");
			stream.println("<Style id=\"myRedPathStyle\">");
			stream.println("<LineStyle>");
			stream.println("<width>4</width>");
			stream.println("<color>FF0000FF</color>");
			stream.println("</LineStyle>");
			stream.println("</Style>");
			stream.println("<Placemark>");
			stream.println("<name>Path</name>");
			stream.println("<styleUrl>#myRedPathStyle</styleUrl>");
			stream.println("<LineString>");
			stream.println("<extrude>1</extrude>");
			stream.println("<tessellate>1</tessellate>");
			stream.println("<coordinates>");
			for(Node n: canvas.node_list) {
				stream.println(n.longitude + "," + n.latitude);
			}
			stream.println("</coordinates>");
			stream.println("</LineString>");
			stream.println("</Placemark>");
			stream.println("</Document>");
			stream.println("</kml>");
			file.stopWriting();	 

		}



	}
}



