public class Controller
{
  private static ViewCanvas viewCanvas;
  private static ControlPanel controlPanel;
  
  public static void main(String[] args)
  {
    viewCanvas = new ViewCanvas(1000, 600);
    controlPanel = new ControlPanel(viewCanvas);
    MainFrame mainFrame = new MainFrame("Navigation System", viewCanvas, controlPanel);
  }
  
  public static void draw()
  {
    viewCanvas.draw();
  }
  
}