//Arjun Jain 
//Honors Computer Science II - Block 4
//June 13 2018
//Purpose: *This is where you change the file* , draws the map and code for drawing the path 
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.ArrayList;

class ViewCanvas extends EventfulImageCanvas
{

	//*This is where to change the data file* 
	LoadData map = new LoadData("Catlin2-allroads");
	int width;
	int height;
	Node node1;
	Node node2;
	boolean pressStartNode = true;
	ArrayList<Node> node_list = new ArrayList<Node>();



	ViewCanvas(int width, int height)
	{
		super(width, height);
	}

	//override resized from EventfulImageCanvas
	public void resized()
	{
		draw();
	}


	void draw()
	{
		width = getWidth();
		height = getHeight();
		Graphics2D pen = getPen();
		clear();
		pen.setColor(Color.blue);

		for(int key: map.links.keySet())
		{
			Node startNode = map.links.get(key).startNode;
			Node endNode = map.links.get(key).endNode;

			int x1 = convertX(startNode.longitude);
			int y1 = convertY(startNode.latitude);
			int x2 = convertX(endNode.longitude);
			int y2 = convertY(endNode.latitude);
			//drawing waypoints for each link 
			for(int i = 0; i < map.links.get(key).waypoints.size() -1; i++) {
				Link_waypoints waypoint1 = map.links.get(key).waypoints.get(i);
				Link_waypoints waypoint2 = map.links.get(key).waypoints.get(i + 1);
				int waypoint_x1 = convertX(waypoint1.longitude);
				int waypoint_y1 = convertY(waypoint1.latitude);
				int waypoint_x2 = convertX(waypoint2.longitude);
				int waypoint_y2 = convertY(waypoint2.latitude);
				pen.drawLine(waypoint_x1,waypoint_y1, waypoint_x2, waypoint_y2);				
			}
		}
		//drawing startNode
		if(node1 != null) {
			pen.setColor(Color.red);
			pen.fillOval(convertX(node1.longitude)-5, convertY(node1.latitude)-5,10, 10);
		}
		//drawing endNode
		if(node2 != null) {
			pen.setColor(Color.orange);
			pen.fillOval(convertX(node2.longitude)-5,convertY(node2.latitude)-5,10, 10);
		}		
		//drawing the route 
		if(node_list != null) {
			drawRoute(node_list);
		}

		display();
	}


	//converts longitude to x-coordinate
	public int convertX(double longitude)
	{
		int x = (int)(((longitude-map.minLong)/(map.maxLong-map.minLong))*width);
		return x;
	}

	//converts latitude to y-coordinate
	public int convertY(double latitude)
	{
		int y = (int)((((latitude-map.minLat)/(map.maxLat-map.minLat))*height)*-1+height);
		return y;
	}

	//converts x-coordinate to longitude
	public double convertLong(int x)
	{
		return ((((double)x/width)*(map.maxLong-map.minLong))+ map.minLong);
	}

	//converts y-coordinate to latitude	
	public double convertLat(int y)
	{
		return (((((double)y-height)/(-1*height))*(map.maxLat-map.minLat))+ map.minLat);
	}

	//override mousePressed from EventfulImageCanvas
	public void mousePressed(MouseEvent event) {	
		if(pressStartNode == true) {
			int mouseX = event.getX();
			int mouseY = event.getY();
			double longitude = convertLong(mouseX);
			double latitude = convertLat(mouseY);
			node1 = map.closestNode(longitude,latitude);
			pressStartNode = false;
		} else {
			double longitude = convertLong(event.getX());
			double latitude = convertLat(event.getY());
			node2 = map.closestNode(longitude,latitude);
			pressStartNode = true;
		}

		draw();
	}

	//Method to draw route 
	//Takes node list (returned from shortestPath method) 
	public void drawRoute(ArrayList<Node> list) {
		Graphics2D pen = getPen();
		pen.setColor(Color.green);
		pen.setStroke(new BasicStroke(4));
		//go through nodes in list returned by shortestPath
		for (Node n: list)
		{
			if (n.previous != null)
			{
				//go through Link neighbors of each node
				for(int i = 0; i < n.previous.neighbors.size(); i++) {
					Link new_link = n.previous.neighbors.get(i);
					//finding link
					if(new_link.startNode == n.previous && new_link.endNode == n) {
						int new_linkID = new_link.linkID;
						//connecting waypoints for each link 
						for(int j = 0; j < map.links.get(new_linkID).waypoints.size() -1; j++) {
							Link_waypoints waypoint1 = map.links.get(new_linkID).waypoints.get(j);
							Link_waypoints waypoint2 = map.links.get(new_linkID).waypoints.get(j + 1);
							int waypoint_x1 = convertX(waypoint1.longitude);
							int waypoint_y1 = convertY(waypoint1.latitude);
							int waypoint_x2 = convertX(waypoint2.longitude);
							int waypoint_y2 = convertY(waypoint2.latitude);
							pen.drawLine(waypoint_x1,waypoint_y1, waypoint_x2, waypoint_y2);				
						}
					}
				}
			}

		}
	}
}