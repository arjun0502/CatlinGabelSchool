//Arjun Jain 
//Honors Computer Science II - Block 4
//June 14 2018
import java.awt.*;
import javax.swing.*;

class MainFrame extends JFrame
{
	MainFrame(String title, Component viewPanel, Component controlPanel)
	{ 
		super(title);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.add(viewPanel, BorderLayout.CENTER);  
		mainPanel.add(controlPanel, BorderLayout.SOUTH);

		getContentPane().add(mainPanel);
		pack();
		setLocationRelativeTo(null);
		setVisible(true);
		toFront();   
	}

}