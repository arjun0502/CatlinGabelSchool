//Arjun Jain 
//Honors Computer Science II - Block 4
//June 14 2018
//Purpose: Class for waypoint objects 
public class Link_waypoints {


	double longitude;
	double latitude;


	public Link_waypoints(double longitude, double latitude) {
		this.longitude = longitude;
		this.latitude = latitude;

	}



}
