//Arjun Jain 
//Honors Computer Science II - Block 4
//June 14 2018
//Purpose:Class for links objects and their fields 
import java.util.ArrayList;

public class Link {

	int linkID;
	Node startNode;
	Node endNode;
	String name;
	double length;
	byte numWays;
	//list of waypoints for each link
	ArrayList<Link_waypoints> waypoints = new ArrayList<Link_waypoints>();

	public Link(int linkID, Node start, Node end, String label, double distance, byte numWays) {
		this.linkID = linkID;
		startNode = start;
		endNode = end;
		name = label;
		length = distance;
		this.numWays = numWays;
	}	


	public ArrayList<Link_waypoints> getArray() {
		return waypoints;
	}

	public void setArray(ArrayList<Link_waypoints> way_pointlist) {
		waypoints = way_pointlist;
	}

	public int getLinkID() {
		return linkID;
	}
}
