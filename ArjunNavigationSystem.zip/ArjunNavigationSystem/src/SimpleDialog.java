import javax.swing.*;

/**
 * This class provides easy access to simple pop-up dialog boxes.
 * 
 *  @author Andrew Merrill, Spring 2006
 *  @version 1.0
 * 
 <pre>
 Example Usage:
 
 SimpleDialog.showMessage("You won the game!");
 
 String response = SimpleDialog.askYesNoQuestion("Are you hungry?");
 
 String response = SimpleDialog.askForInput("What is your favorite color?");
 </pre>
 * 
 */


public class SimpleDialog
{
  private static final String TITLE = "Path Finder";
  
  /**
   * Displays a Yes or No question and waits for the user to select
   * an answer.  If the user closes the dialog box, then the program 
   * exits.
   * 
   * @param question The question to ask.
   * 
   * @return Returns either "yes" or "no".
   */
  
  public static String askYesNoQuestion(String question)
  {
    int result = JOptionPane.showConfirmDialog(null, question, TITLE, JOptionPane.YES_NO_OPTION);
    return convertYesNoToString(result);
  }
  
   /**
   * Displays a prompt and waits for the user to type in
   * a response.  If the user closes the dialog box, then the program 
   * exits.
   * 
   * @param prompt The prompt to display to the user.
   * 
   * @return Returns the response that the user entered.
   */

  public static String askForInput(String prompt)
  {
    String input = JOptionPane.showInputDialog(null, prompt, TITLE, JOptionPane.QUESTION_MESSAGE);
    if (input == null) 
    {
      System.exit(0);
      return null;
    }
    else
    {
      return input;
    }
  }
  
   /**
   * Displays a message to the user in a dialog box.
   * 
   * @param message The message to display to the user.
   */

  
  public static void showMessage(String message)
  {
    JOptionPane.showMessageDialog(null, message, TITLE, JOptionPane.INFORMATION_MESSAGE);
  }
  
  
  private static String convertYesNoToString(int yesOrNo)
  {
    if (yesOrNo == JOptionPane.YES_OPTION)
    {
      return "yes";
    }
    else if (yesOrNo == JOptionPane.NO_OPTION)
    {
      return "no";
    }
    else
    {
      System.exit(0);
      return null;
    }
  }
  
  private SimpleDialog()
  {
  }
  
}