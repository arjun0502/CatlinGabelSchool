//Arjun Jain
//Honors Computer Science - Block 4 
//Photo Editor

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.ArrayList;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class PhotoEditor{
	PhotoCanvas photoCanvas;
	//has buttons 
	PhotoControlPanel photoControlPanel;
	JFrame frame;
	ArrayList<BufferedImage> list;
	//Image you are editing 
	BufferedImage photoImage;
	private Color pen_color;

	public static void main(String[] args)
	{
		new PhotoEditor();
	}

	PhotoEditor()
	{
		JFrame frame = new JFrame("Photo Editor");
		frame.setSize(1366, 768);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		list = new ArrayList<BufferedImage>();

		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());

		photoControlPanel = new PhotoControlPanel();
		photoCanvas = new PhotoCanvas();
		mainPanel.add(photoControlPanel, BorderLayout.SOUTH);
		mainPanel.add(photoCanvas, BorderLayout.CENTER);

		frame.getContentPane().add(mainPanel);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

//Buttons
	class PhotoControlPanel extends JPanel 
	{  
		PhotoControlPanel() 
		{
			add(new OpenFile());
			add(new SaveFile());
			add(new New());
			add(new NegativeColor());
			add(new GreyScale());
			add(new Blur());
			add(new Undo());
			add(new ColorChooserButton());
		}

		
		class OpenFile extends JButton implements ActionListener{
			OpenFile() 
			{
				super("Open File");
				addActionListener(this);
			}

			public void actionPerformed(ActionEvent e) 
			{
				//run when someone clicks button
				JFileChooser choose = new JFileChooser("/Users/jainar/Pictures");
				int returnVal = choose.showOpenDialog(frame);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					//they clicked OK, now need to open a picture
					try {
						photoImage = ImageIO.read(choose.getSelectedFile());
						BufferedImage a = new BufferedImage(photoImage.getColorModel(), photoImage.copyData(null), photoImage.isAlphaPremultiplied(), null).getSubimage(0, 0, photoImage.getWidth(), photoImage.getHeight());
						list.add(a);
						photoCanvas.draw();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			}
		}
	}


	class SaveFile extends JButton implements ActionListener{

		SaveFile(){
			super("Save File");
			addActionListener(this);
		}
		public void actionPerformed(ActionEvent e) 
		{
			JFileChooser choose = new JFileChooser();
			int returnVal = choose.showSaveDialog(null);
			if(returnVal == JFileChooser.APPROVE_OPTION) {
				File selectedFile = choose.getSelectedFile();
				try 
				{
					ImageIO.write(photoImage, "jpg", selectedFile);
				} 
				catch (IOException ex) 
				{
					System.out.println("The file was not saved");
				}
			}
		}

	}

//creates blank screen
	class New extends JButton implements ActionListener {

		New() {
			super("New");
			addActionListener(this);
		}

		public void actionPerformed(ActionEvent arg0) {
			photoImage = new BufferedImage(photoCanvas.getWidth(), photoCanvas.getHeight(), 3);
			photoCanvas.draw();
			BufferedImage a = new BufferedImage(photoImage.getColorModel(), photoImage.copyData(null), photoImage.isAlphaPremultiplied(), null).getSubimage(0, 0, photoImage.getWidth(), photoImage.getHeight());
			list.add(a);
		}
	}
	
	class NegativeColor extends JButton implements ActionListener {

		NegativeColor() {
			super("Negative Color");
			addActionListener(this);
		}

		public int reverseColor(int color)
		{
			color = 255 - color;
			return color;
		}

		public void actionPerformed(ActionEvent e) {
			for (int y=0; y < photoImage.getHeight(); y++) 
			{
				for (int x=0; x < photoImage.getWidth(); x++) 
				{
					int rgb = photoImage.getRGB(x, y);
					Color pixelcolor = new Color(rgb);
					int red = pixelcolor.getRed();
					int green = pixelcolor.getGreen();
					int blue = pixelcolor.getBlue();
					int newrgb = new Color(reverseColor(red), reverseColor(green), reverseColor(blue)).getRGB();
					photoImage.setRGB(x, y, newrgb);
				} 
			}
			BufferedImage a = new BufferedImage(photoImage.getColorModel(), photoImage.copyData(null), photoImage.isAlphaPremultiplied(), null).getSubimage(0, 0, photoImage.getWidth(), photoImage.getHeight());
			list.add(a);
			photoCanvas.draw(); 
		}

	}
	
	
	class GreyScale extends JButton implements ActionListener {

		GreyScale() {
			super("Grey Scale");
			addActionListener(this);
		}

		public void actionPerformed(ActionEvent e) {
			for (int y=0; y < photoImage.getHeight(); y++) 
			{
				for (int x=0; x < photoImage.getWidth(); x++) 
				{
					int rgb = photoImage.getRGB(x, y);
					Color pixelcolor = new Color(rgb);
					int red = pixelcolor.getRed();
					int green = pixelcolor.getGreen();
					int blue = pixelcolor.getBlue();
					int grey = (int)(red*0.21) + (int)(green*0.72) + (int)(blue*0.07);
					int newrgb = new Color(grey, grey, grey).getRGB();
					photoImage.setRGB(x, y, newrgb);
				} 
			}
			BufferedImage a = new BufferedImage(photoImage.getColorModel(), photoImage.copyData(null), photoImage.isAlphaPremultiplied(), null).getSubimage(0, 0, photoImage.getWidth(), photoImage.getHeight());
			list.add(a);
			photoCanvas.draw(); 
		}

	}
	
	class Undo extends JButton implements ActionListener {
		Undo() {
			super("Undo");
			addActionListener(this);
		}

		public void actionPerformed(ActionEvent e) 
		{
			if(list.size()<=1)
				return;
			list.remove(list.size()-1);
			photoImage = list.get(list.size()-1);
			photoCanvas.draw();
		}
	}

	class Blur extends JButton implements ActionListener 
	{
		Blur() 
		{
			super("Blur");
			addActionListener(this);
		}

		public int blur(int x, int y) 
		{
			int redaverage = 0;
			int greenaverage = 0;
			int blueaverage = 0;
			int radius = 4;
			int num_pixels = 0;
			for(int x1 = x - radius; x1 <= x + radius; x1++)
			{
				for(int y1 = y - radius; y1 <= y + radius; y1++)
				{
					if((x1 >= 0 && y1 >= 0) && (x1 < photoImage.getWidth()  && y1 < photoImage.getHeight()))
					{
						Color newcolor = new Color(photoImage.getRGB(x1,y1));
						redaverage += newcolor.getRed();
						greenaverage += newcolor.getGreen();
						blueaverage += newcolor.getBlue();
						num_pixels +=1;
					}
				}
			}
			redaverage /= num_pixels;
			greenaverage /= num_pixels;
			blueaverage /= num_pixels;
			return new Color(redaverage, greenaverage, blueaverage).getRGB();
		}

		public void actionPerformed(ActionEvent e) 
		{
			for (int y = 0; y < photoImage.getHeight(); y++) 
			{
				for (int x = 0; x < photoImage.getWidth(); x++) 
				{
					photoImage.setRGB(x, y, blur(x, y));
				}
			}
			BufferedImage a = new BufferedImage(photoImage.getColorModel(), photoImage.copyData(null), photoImage.isAlphaPremultiplied(), null).getSubimage(0, 0, photoImage.getWidth(), photoImage.getHeight());
			list.add(a);
			photoCanvas.draw(); 
		}
	}

	
	class ColorChooser extends JColorChooser implements ActionListener {

		public void actionPerformed(ActionEvent e) {
			pen_color = getColor();
		}

	}

	class ColorChooserButton extends JButton implements ActionListener {
		ColorChooserButton() 
		{
			super("Color Chooser Button");
			addActionListener(this);
		}

		public void actionPerformed(ActionEvent e) {
			pen_color = JColorChooser.showDialog(null, "Pick a color for pen", pen_color);
		}

	}



	class Mouse implements MouseListener, MouseMotionListener {

		int mX;
		int mY;
		int prevX;
		int prevY;
		int buffer_width;
		int buffer_height;
		int canvas_width;
		int canvas_height;
		double width_ratio;
		double height_ratio;
		boolean mousePrevDragged = false;


		public void mouseClicked(MouseEvent arg0) {
		}
		public void mouseEntered(MouseEvent arg0) {		
		}

		public void mouseExited(MouseEvent arg0) {
		}

		public void mousePressed(MouseEvent mouseEvent) {
			buffer_width = photoImage.getWidth();
			buffer_height = photoImage.getHeight();
			canvas_width = photoCanvas.getWidth();
			canvas_height = photoCanvas.getHeight();
			width_ratio = (double) buffer_width/canvas_width;
			height_ratio = (double) buffer_height/canvas_height;
			prevX = mouseEvent.getX();
			prevX = (int) (prevX * width_ratio);
			prevY = mouseEvent.getY();
			prevY = (int) (prevY * height_ratio);
		}
		//scribble 
		public void mouseDragged(MouseEvent MouseDraggedEvent) {
			mousePrevDragged = true;
			Graphics2D g = photoImage.createGraphics();
			g.setColor(pen_color);
			g.setStroke(new BasicStroke(7));
			mX = MouseDraggedEvent.getX();
			mX = (int) (mX * width_ratio);
			mY = MouseDraggedEvent.getY();
			mY = (int) (mY * height_ratio);
			g.drawLine(prevX, prevY, mX, mY);
			photoCanvas.draw();
			prevX=mX;
			prevY=mY;

		}

		public void mouseReleased(MouseEvent arg0) {
			if(mousePrevDragged) {
				BufferedImage a = new BufferedImage(photoImage.getColorModel(), photoImage.copyData(null), photoImage.isAlphaPremultiplied(), null).getSubimage(0, 0, photoImage.getWidth(), photoImage.getHeight());
				list.add(a);
			}
			mousePrevDragged = false;
		}

		public void mouseMoved(MouseEvent arg0) {
		}

	}
	
	
	class PhotoCanvas extends ImageCanvas
	{
		PhotoCanvas() {
			super(600,400);
			//add it as a listener twice as a mouse listener and Mouse action listener
			Mouse mouse = new Mouse();
			this.addMouseMotionListener(mouse);
			this.addMouseListener(mouse);
		}

		public void draw()
		{
			Graphics pen = getPen();
			clear();
			if(photoImage !=  null) {
				pen.drawImage(photoImage,  0, 0, getWidth(), getHeight(), this);
			}
			display();
		}

		public void resized() {
			draw();
		}

	}
}


