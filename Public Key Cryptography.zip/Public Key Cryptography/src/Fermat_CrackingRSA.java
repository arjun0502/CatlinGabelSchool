//Arjun Jain 
//Honors Computer Science III
//Implementation of Fermat's Factorization Algorithm for Cracking RSA

import java.math.BigInteger;

public class Fermat_CrackingRSA {

	public RSA Fermat_factor(BigInteger n, BigInteger e) {
		BigInteger x = n.sqrt();
		BigInteger y = BigInteger.ZERO;
		
		while((x.pow(2).subtract(y.pow(2))).compareTo(n) != 0) {
			if((x.pow(2).subtract(y.pow(2))).compareTo(n) < 0) {
				x  = x.add(BigInteger.ONE);
			}
			else if((x.pow(2).subtract(y.pow(2))).compareTo(n) > 0) {
				y = y.add(BigInteger.ONE);
			}
		} 
		BigInteger p = x.add(y);
		BigInteger q = x.subtract(y);
		BigInteger totient = n.subtract(p).subtract(q).add(BigInteger.ONE);
		BigInteger d = e.modInverse(totient);
		RSA private_key = new RSA(n, null, d);
		return private_key;
	}


	  public static void main(String[] args) 
	    {
		    //Cracking a message encrypted with 68-bit key 
		  	//Takes around 45 seconds
	        BigInteger n = new BigInteger("265019583304541515309");
	        BigInteger e = new BigInteger("13502471791819624137");
	        Fermat_CrackingRSA ff = new Fermat_CrackingRSA();
			RSA private_key = ff.Fermat_factor(n,e);
			private_key.decrypt("245933951991326807144");
	    }
}