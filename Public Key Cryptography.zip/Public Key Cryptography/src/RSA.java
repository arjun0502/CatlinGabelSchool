//Arjun Jain 
//Honors Computer Science III
//Implementation of RSA Algorithm

import java.math.BigInteger; 
import java.util.Random;
import java.util.BitSet;

public class RSA { 

	private BigInteger p; 
	private BigInteger q; 
	private BigInteger n; 
	private BigInteger totient; 
	private BigInteger e; 
	private BigInteger d; 
	private int bitlength; 
	private Random rand;

	public RSA(BigInteger n, BigInteger e, BigInteger d) {
		this.n = n;
		this.e = e;
		this.d = d;
	}

	public RSA(int bitlength) {
		keyGenerator(bitlength);
	}

	//generates a public and private key given a bit length
	public void keyGenerator(int bitlength) { 
		rand = new Random(); 
		p = BigInteger.probablePrime(bitlength/2, rand); 
		q = BigInteger.probablePrime(bitlength/2, rand); 
		n = p.multiply(q); 
		totient = n.subtract(p).subtract(q).add(BigInteger.ONE);
		e = BigInteger.probablePrime(bitlength/2, rand); 
		while (totient.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(totient) < 0 ) { 
			e.add(BigInteger.ONE); 
		} 
		d = e.modInverse(totient);  
		System.out.println("Public Key: " + bitlength +";" + n + ";" + e);
		System.out.println("Private Key: " + bitlength + ";" + n + ";" + d);
	} 

	public String encrypt(String message) {
		byte[] b = message.getBytes();
		long array[] = BitSet.valueOf(b).toLongArray();
		String s = "";
		for (long l:array) {
			BigInteger be = BigInteger.valueOf(l);
			BigInteger i = be.modPow(e, n); 
			s += i.toString() + ",";
		}
		System.out.println(s);
		return s;
	} 

	public String decrypt(String encrypted) {
		String [] s = encrypted.split(",");
		long[] val = new long[s.length];
		BigInteger k;
		for (int i=0;i<s.length;i++) {
			k = new BigInteger(s[i]);
			k=k.modPow(d, n);
			val[i] = k.longValue();
		}
		byte [] message = BitSet.valueOf(val).toByteArray();
		String m = new String(message);
		System.out.println(m);
		return m;
	}  

	public static void main (String[] args)	{ 

		/*
	//Generating keys with specified bit-length:
		RSA rsa = new RSA(100);

	//Encrypting a question with public key:
		RSA rishi_public_key = new RSA(new BigInteger("45543498809683188757"), new BigInteger("6594467493399699343"), null);
		rishi_public_key.encrypt("What is your favorite color");	   

	//Decrypting Andrew's question private key: Which state borders Wyoming?
		RSA private_key = new RSA(new BigInteger("623595017079607108087259"), null, new BigInteger("393761130625807395287279"));
		private_key.decrypt("538731919192555684781860,80624775643102123627727,188758385594743335137910,472893192717845657813972,424494836629589509510909,583302081037203875641627");

	//Encrypting answer with private key:
		RSA answer_andrew = new RSA(new BigInteger("623595017079607108087259"), new BigInteger("393761130625807395287279"), null);
		answer_andrew.encrypt("Idaho, Montana, Utah, South Dakota, Nebraska, Colorado"); 
		 */	
	} 
}